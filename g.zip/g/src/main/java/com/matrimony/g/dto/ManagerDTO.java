package com.matrimony.g.dto;

public class ManagerDTO {

	private int subId;
	private int subMonth;
	private int subYear;
	private double amount;
	private String subType;
	
	public int getSubId() {
		return subId;
	}
	public void setSubId(int subId) {
		this.subId = subId;
	}
	public int getSubMonth() {
		return subMonth;
	}
	public void setSubMonth(int subMonth) {
		this.subMonth = subMonth;
	}
	public int getSubYear() {
		return subYear;
	}
	public void setSubYear(int subYear) {
		this.subYear = subYear;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	
	
}
