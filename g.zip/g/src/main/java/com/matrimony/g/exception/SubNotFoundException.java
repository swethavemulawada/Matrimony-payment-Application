package com.matrimony.g.exception;

public class SubNotFoundException extends Exception {
	public SubNotFoundException(String msg) {
		super(msg);
}
}
